package team2hotel;

public class Option1 {
   

   //Output all occupied rooms
   public static void option1(Hotel hotel){
      System.out.println("All occupied rooms:");
      hotel.getRoomInfo();
   }

}
