
package team2hotel;

import java.util.Date;



/**
 *
 * @author cpalmares
 */

public class FormMedium {
    
    private String name;
    private String formRoomType;
    private Date startDate;
    private Date endDate; 
    private int guestID;
    private int roomNumber;

    public int getRoomNumber() {
        return roomNumber;
    }

    public void setRoomNumber(int roomNumber) {
        this.roomNumber = roomNumber;
    }

    public int getGuestID() {
        return guestID;
    }

    public void setGuestID(int guestID) {
        this.guestID = guestID;
    }

    public FormMedium() {
        this.name = "";
        this.formRoomType = "";
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setFormRoomType(String formRoomType) {
        this.formRoomType = formRoomType;
    }
    
    public void setFormStartDate(Date formStartDate) {
        this.startDate = formStartDate;
    }
    
    public Date getFormStartDate(){
        return startDate;
    }
    
    public void setFormEndDate(Date endDate) {
        this.endDate = endDate;
    }
    
    public Date getFormEndDate(){
        return endDate;
    }

    public String getName() {
        return name;
    }

    public String getFormRoomType() {
        return formRoomType;
    }
    
    
    
    
}
