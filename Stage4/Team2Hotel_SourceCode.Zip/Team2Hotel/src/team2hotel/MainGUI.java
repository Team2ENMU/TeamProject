

package team2hotel;

import java.awt.Component;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.tree.TreePath;
import static team2hotel.Option2.registerGuest;

/**
 *
 * @author cpalmares
 */
public class MainGUI extends javax.swing.JFrame {
    
    Hotel hotel;
    private Option2 option2Instance;
    private FormMedium obj; // = new FormMedium();
             
               Date selectedDate;
               
    private static CSVHelper csvHelper = new CSVHelper();
    private static final String filename = "guests.csv";
    private static final String delimiter = ",";
    /**
     * Creates new form NewApplication
     */
    public MainGUI() {
        initComponents();
        createHotel();
        readCSV();
    }
            
    private void createHotel(){
         jPanel1.setVisible(false);
         jPanel2.setVisible(false);
             //jPanel1.setVisible(false);         
                        // Day ComboBox
        //dayComboBox = new JComboBox<>();
        for (int day = 1; day <= 31; day++) {
            cboCheckInDay.addItem(day);
            cboCheckOutDay.addItem(day);
        }
        
                cboCheckInDay.setSelectedItem(14);
        cboCheckOutDay.setSelectedItem(14);

        // Month ComboBox
        String[] months = {"January", "February", "March", "April", "May", "June", "July",
                           "August", "September", "October", "November", "December"};
                    for (String month : months) {
                cboCheckInMonth.addItem(month);
                cboCheckOutMonth.addItem(month);
            }
       cboCheckInMonth.setSelectedItem("December");
       cboCheckOutMonth.setSelectedItem("December");
        //monthComboBox = new JComboBox<>(months);

        // Year ComboBox (adjust the range as needed)
        //yearComboBox = new JComboBox<>();
        int currentYear = Calendar.getInstance().get(Calendar.YEAR);
        for (int year = currentYear - 100; year <= currentYear + 100; year++) {
            cboCheckInYear.addItem(year);
            cboCheckOutYear.addItem(year);
        }
        
        cboCheckInYear.setSelectedItem(2023);
        cboCheckOutYear.setSelectedItem(2023);

      //hotel = new Hotel(RandomValues.generateRandomNumber(10, 50));
            hotel = new Hotel(35);
      //Update hotel object rooms array with random values. Pass room count and current array
      //hotel.roomsArray = RandomValues.assignGuestsToRooms(hotel.getNumRooms(), hotel.roomsArray);
      //hotel.roomsArray = 
      
      
      //Hard code 6 default employees to create
      Employees[] aEmployees = new Employees[6];
      aEmployees[0]  = new EmployeesManager(100.26f, "Zach Wilsom",  "Boss", true);
      aEmployees[5] = new Employees(20.20f, "Dak Prescott",  "Receptionist");
      aEmployees[1]  = new Employees(20.21f, "Josh Allen",  "Maintenance");
      aEmployees[2]  = new Employees(20.22f, "Kyler Murray",  "Maintenance");
      aEmployees[3]  = new Employees(30.30f, "Patrick Mahomes",  "Housekeeper");
      aEmployees[4]  = new Employees(30.35f, "Lamar Jackson",  "Housekeeper");
      
      //Loop through all employees. Add them to employees array
      for (Employees employee : aEmployees) {
         hotel.employeesArray.add(employee);         
      }

      //Call menu with hotel object
      //Menu.menu(hotel);
      
      jPanelAddRemoveGuest.setVisible(false);
      jPanelGuestDeadEnd.setVisible(false);

    }
    private void readCSV()
    {
        
        try
        {
            
                                           HashMap<Integer, Date> checkIn = new HashMap<>();
                HashMap<Integer, Date> checkOut = new HashMap<>();
                
            File file = new File(filename);
            FileReader fr = new FileReader(file);
            BufferedReader br = new BufferedReader(fr);
            
            String line = "";
            String[] tempArr;
             Date salary = null;
             Date salary2 = null;
            while ( (line = br.readLine()) != null)
            {
                tempArr = line.split(delimiter);
                for (String field : tempArr)
                {
                    System.out.println(field + " ");
                }
                
                int id = Integer.valueOf(tempArr[0]);
                String name = tempArr[1];
                int age = Integer.valueOf(tempArr[2]);

                
                        try {
                            SimpleDateFormat dateFormat = new SimpleDateFormat("MMM dd HH:mm:ss z yyyy");
            salary = dateFormat.parse(tempArr[3]);
            salary2 = dateFormat.parse(tempArr[4]);
        } catch (ParseException e) {
            e.printStackTrace();
        }

            checkIn.put(age, salary);
            checkOut.put(age, salary2);
                
                Guest guest = new Guest(name, id);
                guest.setRoomNumber(age);
                csvHelper.addGuest(guest);             

            }
            
            
            br.close();
            
            
            
            
            
            
            HashMap<Integer, Guest> guests = csvHelper.getGuests(); 
            for (Map.Entry guest : guests.entrySet())
            {
                String row = "";
                int guestID = (Integer)guest.getKey();
                Guest gues = csvHelper.getGuest(guestID);

                String name = gues.getGuestName();
                int age = gues.getRoomNumber(); //TODO
                //double salary = 1.01; //TODO

                


                row = String.valueOf(guestID) + "," + name + "," +
                        String.valueOf(age) + "," + String.valueOf(salary) + 
                        "\n";
                
                
                for (Rooms room : hotel.roomsArray) {
                    
        
                    if(room.getRoomID() == age){
                        room.setGuest(gues);
                        room.setStartDate(checkIn.get(age));
                        room.setEndDate(checkOut.get(age));
                    }
                }

            

            }
            
            
            lblStatus.setText("Successfully loaded");
            
        }
        catch(IOException e)
        {
            JOptionPane.showMessageDialog(this, "Error reading the file");
        }
    }
    private void updateCSV()
    {
        try
        {
            
            // Make a copy of the original fike
            
//            File oldFile = new File(filename);
//            File new_file = new File(filename+".bkp");
//            
//            Files.copy(oldFile.toPath(), new_file.toPath());
            HashMap<Integer, Date> checkIn = new HashMap<>();
            HashMap<Integer, Date> checkOut = new HashMap<>();
            
                    
        for (Rooms room : hotel.roomsArray) {
         if(room.getGuest() != null){
            room.getGuest().setRoomNumber(room.getRoomID());
            csvHelper.addGuest(room.getGuest());
            checkIn.put(room.getRoomID(), room.getStartDate());
            checkOut.put(room.getRoomID(), room.getEndDate());
         }
      }
                    
            File file = new File(filename);
            BufferedWriter bf = new BufferedWriter(new FileWriter(file));

            // Traverese the map of customers and ovewrite the file.
            HashMap<Integer, Guest> guests = csvHelper.getGuests(); 
            for (Map.Entry guest : guests.entrySet())
            {
                String row = "";
                int guestID = (Integer)guest.getKey();
                Guest gues = csvHelper.getGuest(guestID);

                String name = gues.getGuestName();
                int age = gues.getRoomNumber(); //TODO
                Date checkInDate = checkIn.get(age); //TODO
                Date checkOutDate = checkOut.get(age); //TODO
                SimpleDateFormat dateFormat = new SimpleDateFormat("MMM dd HH:mm:ss z yyyy");
                
                String checkInDateString = dateFormat.format(checkInDate); //dateToString(checkInDate);
                String checkOutDateString = dateFormat.format(checkOutDate); //dateToString(checkInDate);
               

                row = String.valueOf(guestID) + "," + name + "," +
                        String.valueOf(age) + "," + String.valueOf(checkInDateString) + "," + String.valueOf(checkOutDateString) + 
                        "\n";

                // Add the row to the file
                bf.write(row);
            }
            bf.close();
            
            lblStatus.setText("Successfully Updated");
            
        }
        catch(IOException e)
        {
            JOptionPane.showMessageDialog(this, "Error writing the file");
        }
        
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLayeredPane1 = new javax.swing.JLayeredPane();
        jPanel2 = new javax.swing.JPanel();
        jButton2 = new javax.swing.JButton();
        jLabel9 = new javax.swing.JLabel();
        checkbox1 = new java.awt.Checkbox();
        txtEmpName = new java.awt.TextField();
        txtJobTitle = new java.awt.TextField();
        label1 = new java.awt.Label();
        label2 = new java.awt.Label();
        label3 = new java.awt.Label();
        txtSalary = new javax.swing.JFormattedTextField();
        jButton4 = new javax.swing.JButton();
        jLabel10 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTree1 = new javax.swing.JTree();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jButton1 = new javax.swing.JButton();
        jPanelGuestServices = new javax.swing.JPanel();
        lblStatus = new javax.swing.JLabel();
        btnGuestServices = new javax.swing.JButton();
        btnReports = new javax.swing.JButton();
        btnAdmin = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jPanelAddRemoveGuest = new javax.swing.JPanel();
        btnRegisterGuest = new javax.swing.JButton();
        btnRemoveGuest = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jPanelGuestDeadEnd = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        txtFullName = new javax.swing.JTextField();
        cboRoomType = new javax.swing.JComboBox<>();
        txtID = new javax.swing.JFormattedTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        btnSubmit = new javax.swing.JButton();
        btnBack = new javax.swing.JButton();
        cboCheckInMonth = new javax.swing.JComboBox<>();
        cboCheckInDay = new javax.swing.JComboBox<>();
        cboCheckInYear = new javax.swing.JComboBox<>();
        cboCheckOutMonth = new javax.swing.JComboBox<>();
        cboCheckOutDay = new javax.swing.JComboBox<>();
        cboCheckOutYear = new javax.swing.JComboBox<>();
        btnRemove = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jButton5 = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        menuBar = new javax.swing.JMenuBar();
        fileMenu = new javax.swing.JMenu();
        loadCSVMenuItem = new javax.swing.JMenuItem();
        saveCSVMenuItem = new javax.swing.JMenuItem();
        exitMenuItem = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setTitle("Hotel Management System");

        jLayeredPane1.addContainerListener(new java.awt.event.ContainerAdapter() {
            public void componentAdded(java.awt.event.ContainerEvent evt) {
                jLayeredPane1ComponentAdded(evt);
            }
        });
        jLayeredPane1.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jLayeredPane1FocusGained(evt);
            }
        });
        jLayeredPane1.addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentShown(java.awt.event.ComponentEvent evt) {
                jLayeredPane1ComponentShown(evt);
            }
        });
        jLayeredPane1.setLayout(new javax.swing.OverlayLayout(jLayeredPane1));

        jPanel2.setBackground(new java.awt.Color(51, 51, 51));

        jButton2.setText("Back");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jLabel9.setText("Add Employee");

        checkbox1.setLabel("Is a Manager?");

        label1.setText("Name:");

        label2.setText("Salary:");

        label3.setText("Title:");

        txtSalary.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(new java.text.DecimalFormat("#0.00"))));
        txtSalary.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtSalaryActionPerformed(evt);
            }
        });

        jButton4.setText("Submit");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/team2hotel/Images/blog-header-hotel-reception-desk-with-bell.jpg"))); // NOI18N

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(336, 336, 336)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                            .addComponent(jButton4)
                            .addComponent(jButton2)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(13, 13, 13)
                        .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 651, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(26, 26, 26)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(label3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(label2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(label1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(checkbox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtEmpName, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txtJobTitle, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtSalary, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(336, 336, 336)
                        .addComponent(jLabel9)))
                .addContainerGap(62, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel9)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 36, Short.MAX_VALUE)
                        .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 257, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(28, 28, 28))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(95, 95, 95)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtEmpName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(label1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(30, 30, 30)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(txtSalary, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(21, 21, 21)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtJobTitle, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(label3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(checkbox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(label2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addComponent(jButton4)
                .addGap(8, 8, 8)
                .addComponent(jButton2)
                .addContainerGap())
        );

        label3.getAccessibleContext().setAccessibleName("Title:");

        jLayeredPane1.add(jPanel2);

        jPanel1.setBackground(new java.awt.Color(51, 51, 51));
        jPanel1.setPreferredSize(new java.awt.Dimension(971, 411));

        javax.swing.tree.DefaultMutableTreeNode treeNode1 = new javax.swing.tree.DefaultMutableTreeNode("Reports");
        javax.swing.tree.DefaultMutableTreeNode treeNode2 = new javax.swing.tree.DefaultMutableTreeNode("Rooms");
        javax.swing.tree.DefaultMutableTreeNode treeNode3 = new javax.swing.tree.DefaultMutableTreeNode("List All Occupied Rooms");
        treeNode2.add(treeNode3);
        treeNode3 = new javax.swing.tree.DefaultMutableTreeNode("List All Unclean Rooms");
        treeNode2.add(treeNode3);
        treeNode3 = new javax.swing.tree.DefaultMutableTreeNode("List All Previous Guest Stays");
        treeNode2.add(treeNode3);
        treeNode1.add(treeNode2);
        treeNode2 = new javax.swing.tree.DefaultMutableTreeNode("Employees");
        treeNode3 = new javax.swing.tree.DefaultMutableTreeNode("List All Employees");
        treeNode2.add(treeNode3);
        treeNode1.add(treeNode2);
        jTree1.setModel(new javax.swing.tree.DefaultTreeModel(treeNode1));
        jTree1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTree1MouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(jTree1);

        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jScrollPane3.setViewportView(jTextArea1);

        jButton1.setText("Back");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 276, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 692, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(423, 423, 423)
                .addComponent(jButton1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 359, Short.MAX_VALUE)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.Alignment.LEADING))
                .addGap(18, 18, 18)
                .addComponent(jButton1)
                .addContainerGap(8, Short.MAX_VALUE))
        );

        jLayeredPane1.add(jPanel1);

        jPanelGuestServices.setBackground(new java.awt.Color(102, 102, 102));
        jPanelGuestServices.setMaximumSize(new java.awt.Dimension(971, 411));
        jPanelGuestServices.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jPanelGuestServicesFocusGained(evt);
            }
        });

        btnGuestServices.setText("Guest Services");
        btnGuestServices.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuestServicesActionPerformed(evt);
            }
        });

        btnReports.setText("Reports");
        btnReports.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnReportsActionPerformed(evt);
            }
        });

        btnAdmin.setText("Administrative");
        btnAdmin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAdminActionPerformed(evt);
            }
        });

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/team2hotel/Images/sem-hotels-tablet.jpg"))); // NOI18N

        javax.swing.GroupLayout jPanelGuestServicesLayout = new javax.swing.GroupLayout(jPanelGuestServices);
        jPanelGuestServices.setLayout(jPanelGuestServicesLayout);
        jPanelGuestServicesLayout.setHorizontalGroup(
            jPanelGuestServicesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelGuestServicesLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanelGuestServicesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanelGuestServicesLayout.createSequentialGroup()
                        .addComponent(lblStatus, javax.swing.GroupLayout.PREFERRED_SIZE, 178, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnGuestServices, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(83, 83, 83)
                        .addComponent(btnReports, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(77, 77, 77)
                        .addComponent(btnAdmin, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(279, 279, 279))
                    .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );
        jPanelGuestServicesLayout.setVerticalGroup(
            jPanelGuestServicesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanelGuestServicesLayout.createSequentialGroup()
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 366, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanelGuestServicesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnGuestServices)
                    .addComponent(btnReports)
                    .addComponent(btnAdmin)
                    .addComponent(lblStatus))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jLayeredPane1.add(jPanelGuestServices);

        jPanelAddRemoveGuest.setBackground(new java.awt.Color(102, 102, 255));
        jPanelAddRemoveGuest.setMaximumSize(new java.awt.Dimension(971, 411));
        jPanelAddRemoveGuest.setPreferredSize(new java.awt.Dimension(971, 411));

        btnRegisterGuest.setText("Register Guest");
        btnRegisterGuest.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRegisterGuestActionPerformed(evt);
            }
        });

        btnRemoveGuest.setText("Remove Guest");
        btnRemoveGuest.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRemoveGuestActionPerformed(evt);
            }
        });

        jButton3.setText("Back");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/team2hotel/Images/900368.jpg"))); // NOI18N

        javax.swing.GroupLayout jPanelAddRemoveGuestLayout = new javax.swing.GroupLayout(jPanelAddRemoveGuest);
        jPanelAddRemoveGuest.setLayout(jPanelAddRemoveGuestLayout);
        jPanelAddRemoveGuestLayout.setHorizontalGroup(
            jPanelAddRemoveGuestLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
            .addGroup(jPanelAddRemoveGuestLayout.createSequentialGroup()
                .addGroup(jPanelAddRemoveGuestLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanelAddRemoveGuestLayout.createSequentialGroup()
                        .addGap(285, 285, 285)
                        .addComponent(btnRegisterGuest)
                        .addGap(148, 148, 148)
                        .addComponent(btnRemoveGuest))
                    .addGroup(jPanelAddRemoveGuestLayout.createSequentialGroup()
                        .addGap(441, 441, 441)
                        .addComponent(jButton3)))
                .addContainerGap(296, Short.MAX_VALUE))
        );
        jPanelAddRemoveGuestLayout.setVerticalGroup(
            jPanelAddRemoveGuestLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanelAddRemoveGuestLayout.createSequentialGroup()
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 333, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanelAddRemoveGuestLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnRegisterGuest)
                    .addComponent(btnRemoveGuest))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButton3)
                .addContainerGap())
        );

        jLayeredPane1.setLayer(jPanelAddRemoveGuest, javax.swing.JLayeredPane.PALETTE_LAYER);
        jLayeredPane1.add(jPanelAddRemoveGuest);

        jPanelGuestDeadEnd.setBackground(new java.awt.Color(102, 102, 102));
        jPanelGuestDeadEnd.setMaximumSize(new java.awt.Dimension(971, 411));
        jPanelGuestDeadEnd.setPreferredSize(new java.awt.Dimension(971, 411));
        jPanelGuestDeadEnd.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jPanelGuestDeadEndFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jPanelGuestDeadEndFocusLost(evt);
            }
        });
        jPanelGuestDeadEnd.addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentShown(java.awt.event.ComponentEvent evt) {
                jPanelGuestDeadEndComponentShown(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Avenir", 1, 24)); // NOI18N
        jLabel1.setText("Add Reservation");

        cboRoomType.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Standard", "Suite", "PentHouse" }));
        cboRoomType.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboRoomTypeActionPerformed(evt);
            }
        });

        txtID.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(new java.text.DecimalFormat("#0"))));
        txtID.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtIDFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtIDFocusLost(evt);
            }
        });
        txtID.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtIDActionPerformed(evt);
            }
        });

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Full Name", "Check-in", "Check-out", "Room Type", "Room Number"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.Object.class, java.lang.Integer.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        btnSubmit.setText("Submit");
        btnSubmit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSubmitActionPerformed(evt);
            }
        });

        btnBack.setText("Back");
        btnBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackActionPerformed(evt);
            }
        });

        cboCheckInMonth.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboCheckInMonthActionPerformed(evt);
            }
        });

        cboCheckInYear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboCheckInYearActionPerformed(evt);
            }
        });

        cboCheckOutMonth.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboCheckOutMonthActionPerformed(evt);
            }
        });

        cboCheckOutYear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboCheckOutYearActionPerformed(evt);
            }
        });

        btnRemove.setText("Check-out Guest");
        btnRemove.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRemoveActionPerformed(evt);
            }
        });

        jLabel4.setText("ID:");

        jLabel5.setText("Full name:");

        jLabel6.setText("Check-in:");

        jLabel7.setText("Check-out:");

        jLabel8.setText("Preferred Room type:");

        jButton5.setText("Refresh");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        jLabel11.setText("Available Rooms:");

        jLabel12.setText("-");

        javax.swing.GroupLayout jPanelGuestDeadEndLayout = new javax.swing.GroupLayout(jPanelGuestDeadEnd);
        jPanelGuestDeadEnd.setLayout(jPanelGuestDeadEndLayout);
        jPanelGuestDeadEndLayout.setHorizontalGroup(
            jPanelGuestDeadEndLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelGuestDeadEndLayout.createSequentialGroup()
                .addGroup(jPanelGuestDeadEndLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanelGuestDeadEndLayout.createSequentialGroup()
                        .addGap(361, 361, 361)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 209, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanelGuestDeadEndLayout.createSequentialGroup()
                        .addGap(369, 369, 369)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 599, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanelGuestDeadEndLayout.createSequentialGroup()
                        .addGap(32, 32, 32)
                        .addGroup(jPanelGuestDeadEndLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanelGuestDeadEndLayout.createSequentialGroup()
                                .addGroup(jPanelGuestDeadEndLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(jLabel4)
                                    .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, 68, Short.MAX_VALUE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanelGuestDeadEndLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanelGuestDeadEndLayout.createSequentialGroup()
                                        .addComponent(cboCheckOutMonth, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(5, 5, 5)
                                        .addComponent(cboCheckOutDay, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(cboCheckOutYear, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanelGuestDeadEndLayout.createSequentialGroup()
                                        .addComponent(cboCheckInMonth, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(5, 5, 5)
                                        .addComponent(cboCheckInDay, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(cboCheckInYear, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(txtFullName, javax.swing.GroupLayout.PREFERRED_SIZE, 218, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtID, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btnRemove)))
                            .addGroup(jPanelGuestDeadEndLayout.createSequentialGroup()
                                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(cboRoomType, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(18, 18, 18)
                        .addGroup(jPanelGuestDeadEndLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                            .addComponent(btnSubmit)
                            .addComponent(btnBack))
                        .addGap(222, 222, 222)
                        .addComponent(jButton5)
                        .addGap(43, 43, 43)
                        .addComponent(jLabel11)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel12)))
                .addContainerGap(9, Short.MAX_VALUE))
        );
        jPanelGuestDeadEndLayout.setVerticalGroup(
            jPanelGuestDeadEndLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelGuestDeadEndLayout.createSequentialGroup()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanelGuestDeadEndLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanelGuestDeadEndLayout.createSequentialGroup()
                        .addGroup(jPanelGuestDeadEndLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanelGuestDeadEndLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtFullName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel5))
                        .addGap(18, 18, 18)
                        .addGroup(jPanelGuestDeadEndLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(cboCheckInMonth, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cboCheckInDay, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cboCheckInYear, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel6))
                        .addGap(28, 28, 28)
                        .addGroup(jPanelGuestDeadEndLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(cboCheckOutMonth, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cboCheckOutDay, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cboCheckOutYear, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel7))
                        .addGap(18, 18, 18)
                        .addGroup(jPanelGuestDeadEndLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(cboRoomType, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(29, 29, 29)
                        .addComponent(btnRemove)
                        .addGap(15, 15, 15))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 282, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanelGuestDeadEndLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnSubmit)
                    .addComponent(jButton5)
                    .addComponent(jLabel11)
                    .addComponent(jLabel12))
                .addGap(11, 11, 11)
                .addComponent(btnBack)
                .addContainerGap())
        );

        jLayeredPane1.setLayer(jPanelGuestDeadEnd, javax.swing.JLayeredPane.MODAL_LAYER);
        jLayeredPane1.add(jPanelGuestDeadEnd);

        fileMenu.setMnemonic('f');
        fileMenu.setText("File");

        loadCSVMenuItem.setMnemonic('s');
        loadCSVMenuItem.setText("Load CSV");
        loadCSVMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                loadCSVMenuItemActionPerformed(evt);
            }
        });
        fileMenu.add(loadCSVMenuItem);

        saveCSVMenuItem.setMnemonic('a');
        saveCSVMenuItem.setText("Save CSV");
        saveCSVMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveCSVMenuItemActionPerformed(evt);
            }
        });
        fileMenu.add(saveCSVMenuItem);

        exitMenuItem.setMnemonic('x');
        exitMenuItem.setText("Exit");
        exitMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitMenuItemActionPerformed(evt);
            }
        });
        fileMenu.add(exitMenuItem);

        menuBar.add(fileMenu);

        setJMenuBar(menuBar);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLayeredPane1)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLayeredPane1)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void exitMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitMenuItemActionPerformed
updateCSV();
        System.exit(0);
    }//GEN-LAST:event_exitMenuItemActionPerformed

    private void btnGuestServicesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuestServicesActionPerformed
        // TODO add your handling code here:
        //hotel.roomsArray = Option2.option2(hotel);
        jPanelAddRemoveGuest.setVisible(true);
        
        //jLayeredPane1.repaint();
    }//GEN-LAST:event_btnGuestServicesActionPerformed

    private void btnRegisterGuestActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRegisterGuestActionPerformed
        //hotel.roomsArray = Option2.registerGuest(hotel);
            JLabel newLabel = new JLabel("EDIT");
            jPanelGuestDeadEnd.add(newLabel);
        
        //newLabel.add(jPanelGuestDeadEnd);
        //jPanelGuestDeadEnd.getComponent();
        btnRemove.setVisible(false);
        jLabel1.setText("Add Reservation");   
        jPanelGuestDeadEnd.setVisible(true);
        
    }//GEN-LAST:event_btnRegisterGuestActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
        jPanelAddRemoveGuest.setVisible(false);
    }//GEN-LAST:event_jButton3ActionPerformed

    private void btnAdminActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAdminActionPerformed
        // TODO add your handling code here:
        jPanel2.setVisible(true);
    }//GEN-LAST:event_btnAdminActionPerformed

    private void btnSubmitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSubmitActionPerformed
        registerUser();
        refreshTable();
    }//GEN-LAST:event_btnSubmitActionPerformed

    private void registerUser(){
        // TODO add your handling code here:
        //hotel.roomsArray = registerGuest(hotel);
                FormMedium jk = new FormMedium();

        // Access and update the variable in Option2.java
        //jk.setSomeVariable("New Value");

        // Retrieve the updated value
        //String updatedValue = jk.getSomeVariable();
                jk.setName(txtFullName.getText());
                jk.setFormRoomType(String.valueOf(cboRoomType.getSelectedItem())); //String.valueOf(jComboBox1.getSelectedItem())
                
                if(!txtID.getText().isEmpty()){
                   jk.setGuestID(Integer.valueOf(txtID.getText()));
                }
                

                
        
                        int day = (int) cboCheckInDay.getSelectedItem();
                String month = (String) cboCheckInMonth.getSelectedItem();
                int year = (int) cboCheckInYear.getSelectedItem();

                // Do something with the selected date
                //String selectedDate = day + " " + month + " " + year;
                
              
                
                SimpleDateFormat dateFormat = new SimpleDateFormat("d MMMM yyyy");
                
                try{
                selectedDate = dateFormat.parse(day + " " + month + " " + year);
                        } catch (ParseException e) {
            e.printStackTrace();
        }
                
                jk.setFormStartDate(selectedDate);
                
 
                
                                        day = (int) cboCheckOutDay.getSelectedItem();
                month = (String) cboCheckOutMonth.getSelectedItem();
                year = (int) cboCheckOutYear.getSelectedItem();

                dateFormat = new SimpleDateFormat("d MMMM yyyy");
                
                try{
                selectedDate = dateFormat.parse(day + " " + month + " " + year);
                        } catch (ParseException e) {
            e.printStackTrace();
        }
                
                
                jk.setFormEndDate(selectedDate);

        hotel.roomsArray = registerGuest(hotel, jk);
    }
    
    private void btnBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackActionPerformed
        // TODO add your handling code here:
        //jLabel2
        

        jPanelGuestDeadEnd.setVisible(false);
        Option1.option1(hotel);
    }//GEN-LAST:event_btnBackActionPerformed

    private void cboCheckInYearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboCheckInYearActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cboCheckInYearActionPerformed

    private void cboCheckInMonthActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboCheckInMonthActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cboCheckInMonthActionPerformed

    private void btnRemoveGuestActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRemoveGuestActionPerformed
        //jPanelGuestDeadEnd.setVisible(true);
        //hotel.roomsArray = Option2.removeGuest(hotel);
        jLabel1.setText("Check-out Guest");
        btnRemove.setVisible(true);
        jPanelGuestDeadEnd.setVisible(true);
    }//GEN-LAST:event_btnRemoveGuestActionPerformed

    private void jPanelGuestDeadEndFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jPanelGuestDeadEndFocusGained

    }//GEN-LAST:event_jPanelGuestDeadEndFocusGained

    private void jPanelGuestDeadEndComponentShown(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_jPanelGuestDeadEndComponentShown
        
        
       
        txtID.setText("");
        txtFullName.setText("");

        refreshTable();
        
    }//GEN-LAST:event_jPanelGuestDeadEndComponentShown

private void refreshTable(){
        
              DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
      model.setRowCount(0);
        
        
        for (Rooms room : hotel.roomsArray) {
         if(room.getGuest() != null){
            model.addRow(new Object[]{room.getGuest().getuserID(), room.getGuest().getGuestName(), room.getStartDate(), room.getEndDate(), room.getRoomType(), room.getRoomID()});
         }
      }
                txtID.setText("");
        txtFullName.setText("");
        
        
        jLabel12.setText(String.valueOf(hotel.getAvailableRoomCount()));
        
}

    
    private void cboCheckOutMonthActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboCheckOutMonthActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cboCheckOutMonthActionPerformed

    private void cboCheckOutYearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboCheckOutYearActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cboCheckOutYearActionPerformed

    private void txtIDFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtIDFocusLost
                      DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
      model.setRowCount(0);
        
        
        for (Rooms room : hotel.roomsArray) {
         if(room.getGuest() != null && (txtID.getText().contains(String.valueOf(room.getGuest().getuserID())))){
            model.addRow(new Object[]{room.getGuest().getuserID(), room.getGuest().getGuestName(), room.getStartDate(), room.getEndDate(), room.getRoomType(), room.getRoomID()});
         }
      }
    }//GEN-LAST:event_txtIDFocusLost

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        // TODO add your handling code here:

        txtID.setText(String.valueOf(jTable1.getValueAt(jTable1.getSelectedRow(), 0)));
        txtFullName.setText(String.valueOf(jTable1.getValueAt(jTable1.getSelectedRow(), 1)));
        

        
        
        SimpleDateFormat yearFormat = new SimpleDateFormat("yyyy");
        int yearString = Integer.valueOf(yearFormat.format(jTable1.getValueAt(jTable1.getSelectedRow(), 2)));
        
        SimpleDateFormat monthFormat = new SimpleDateFormat("MMMM");
        String monthString = monthFormat.format(jTable1.getValueAt(jTable1.getSelectedRow(), 2));
        
        SimpleDateFormat dayFormat = new SimpleDateFormat("d");
        int dayString = Integer.valueOf(dayFormat.format(jTable1.getValueAt(jTable1.getSelectedRow(), 2)));
        
        cboCheckInMonth.setSelectedItem(monthString);
        cboCheckInDay.setSelectedItem(dayString);
        cboCheckInYear.setSelectedItem(yearString);
        
        yearFormat = new SimpleDateFormat("yyyy");
        yearString = Integer.valueOf(yearFormat.format(jTable1.getValueAt(jTable1.getSelectedRow(), 3)));
        
        monthFormat = new SimpleDateFormat("MMMM");
        monthString = monthFormat.format(jTable1.getValueAt(jTable1.getSelectedRow(), 3));
        
        dayFormat = new SimpleDateFormat("d");
        dayString = Integer.valueOf(dayFormat.format(jTable1.getValueAt(jTable1.getSelectedRow(), 3)));
        
        cboCheckOutMonth.setSelectedItem(monthString);
        cboCheckOutDay.setSelectedItem(dayString);
        cboCheckOutYear.setSelectedItem(yearString);

    }//GEN-LAST:event_jTable1MouseClicked

    
   
    
    
    private void btnRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRemoveActionPerformed
        Integer foo = (Integer) (jTable1.getValueAt(jTable1.getSelectedRow(), 5));
        hotel.roomsArray = Option2.removeGuest(hotel, foo);
        refreshTable();
        jTable1.getSelectionModel().clearSelection();
        txtID.setText("");
        txtFullName.setText("");
    }//GEN-LAST:event_btnRemoveActionPerformed

    private void jPanelGuestDeadEndFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jPanelGuestDeadEndFocusLost
        // TODO add your handling code here:
        txtID.setText("");
        txtFullName.setText("");
    }//GEN-LAST:event_jPanelGuestDeadEndFocusLost

    private void txtIDFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtIDFocusGained
        // TODO add your handling code here:
        jTable1.getSelectionModel().clearSelection();
        txtID.setText("");
        txtFullName.setText("");
    }//GEN-LAST:event_txtIDFocusGained

    private void saveCSVMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveCSVMenuItemActionPerformed
        // TODO add your handling code here:
        updateCSV();
    }//GEN-LAST:event_saveCSVMenuItemActionPerformed

    private void loadCSVMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_loadCSVMenuItemActionPerformed
        // TODO add your handling code here:
        readCSV();
//DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
//model.setRowCount(0);
//model.addRow(new Object[]{guestID, name, null, null, "Standard", age});

    }//GEN-LAST:event_loadCSVMenuItemActionPerformed

    private void jPanelGuestServicesFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jPanelGuestServicesFocusGained
        // TODO add your handling code here:

    }//GEN-LAST:event_jPanelGuestServicesFocusGained

    private void jLayeredPane1FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jLayeredPane1FocusGained
        // TODO add your handling code here:
    }//GEN-LAST:event_jLayeredPane1FocusGained

    private void jLayeredPane1ComponentShown(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_jLayeredPane1ComponentShown
        // TODO add your handling code here:
    }//GEN-LAST:event_jLayeredPane1ComponentShown

    private void jLayeredPane1ComponentAdded(java.awt.event.ContainerEvent evt) {//GEN-FIRST:event_jLayeredPane1ComponentAdded
        // TODO add your handling code here:

    }//GEN-LAST:event_jLayeredPane1ComponentAdded

    private void btnReportsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnReportsActionPerformed
        // TODO add your handling code here:
        //jLayeredPane1.moveToBack(jPanel1);
        //jPanelGuestServices.moveToBack(jPanel1);
        //jPanel1.setVisible(true);

        jPanel1.setVisible(true);

    }//GEN-LAST:event_btnReportsActionPerformed

    private void jTree1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTree1MouseClicked
        // TODO add your handling code here:
        TreePath selectedPath = jTree1.getSelectionPath();
        JTextArea jjj = jTextArea1;
        if (selectedPath != null) {
        Object selectedNode = selectedPath.getLastPathComponent();
       

        if(selectedNode.toString().contains("List All")){
           //JOptionPane.showMessageDialog(this, "Selected Item: " + selectedNode);
           /*
           Reports
 Rooms 
  List All Occupied Rooms
  List All Unclean Rooms
  List All Previous Guest Stays
 Employees
  List All Employees
           */
           String sOutput = "";
            switch (selectedNode.toString()) {
            case "List All Occupied Rooms":
                for (Rooms room : hotel.roomsArray) {
         if(room.getGuest() != null){
            sOutput += "Room number: " + room.getRoomID() + ".\nGuest is " + room.getGuest().getGuestName() + "\nID: " + room.getGuest().getuserID() +
            "\nRoom type: " + room.getRoomType() + ".\nNightly Cost: $" + room.getRoomCost() +
            room.getFeatures() +
            "\n\tCheck in date: " + room.getStartDate() +
            "\n\tCheck out date: " + room.getEndDate() + "\n********\n";
         }
      }
                break;
            case "List All Unclean Rooms":
                for (int i = 0; i < hotel.roomsArray.length; i++) {
                Rooms room = hotel.roomsArray[i]; 
                if (!room.isClean()) {
                sOutput += "Unclean room number: " + room.getRoomID();
                }
                }
                
                if(sOutput.isEmpty()){
                    sOutput = "All clean!";
                }
                
                break;
            case "List All Previous Guest Stays":
                         for (GuestArchive guestArchive : hotel.guestHistoricStaysArray) {
            sOutput += ("Guest: " + guestArchive.getGuestName() + ".\nDays stayed: " + guestArchive.getNumberofDaysStayed() + "\nRoom type: " + guestArchive.getRoomType() + "\nID: " + guestArchive.getuserID() + "********");
         }
                break;
            case "List All Employees":
                      for (Employees employees : hotel.employeesArray) {
         
         //User BigDecimal to round employee salary
         BigDecimal number = new BigDecimal(employees.getHourlyWage());
         RoundingMode roundingMode = RoundingMode.HALF_UP;
         BigDecimal roundedNumber = number.setScale(2, roundingMode);

         String status = employees.isActiveEmployee() ? "Active" : "Retired";
         String jobTitle = employees.getJobTitle().replaceAll("\\s+", " ");

         
         sOutput += "Employee: " + employees.getName() + ".\nJob title: " + jobTitle + "\nWage: " + roundedNumber+ "\nID: " + employees.getEmpID() + "\nStatus: " + status + "\n********";
      }
                break;
            default:
                break;
        }
            jjj.setText(sOutput);
           
           
        }
        
        }
        
    }//GEN-LAST:event_jTree1MouseClicked

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        jPanel1.setVisible(false);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void cboRoomTypeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboRoomTypeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cboRoomTypeActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        jPanel2.setVisible(false);
    }//GEN-LAST:event_jButton2ActionPerformed

    private void txtSalaryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtSalaryActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtSalaryActionPerformed

    
    
    
    
    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
      String empName = txtEmpName.getText();
      Float hourlyWage = Float.valueOf(txtSalary.getText());
      String jobTitle = txtJobTitle.getText();
      boolean exit = false;
      String isManager = "";
      
      if(checkbox1.getState()){
          isManager = "Y";
      }

      //If manager, create a manager object
      Employees employees;
      if(isManager.equals("Y")){
         employees = new EmployeesManager(hourlyWage, empName, jobTitle, true);
      }else{
         employees = new Employees(hourlyWage, empName, jobTitle);         
      }

      //Add to employeeArray list
      hotel.employeesArray.add(employees);

      txtEmpName.setText("");
      txtSalary.setText("");
      txtJobTitle.setText("");
      checkbox1.setState(false);
      
      JOptionPane.showMessageDialog(this, "New employee created!");
    }//GEN-LAST:event_jButton4ActionPerformed

    private void txtIDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtIDActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtIDActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        refreshTable();
    }//GEN-LAST:event_jButton5ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MainGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MainGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MainGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MainGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MainGUI().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAdmin;
    private javax.swing.JButton btnBack;
    private javax.swing.JButton btnGuestServices;
    private javax.swing.JButton btnRegisterGuest;
    public javax.swing.JButton btnRemove;
    private javax.swing.JButton btnRemoveGuest;
    private javax.swing.JButton btnReports;
    private javax.swing.JButton btnSubmit;
    private javax.swing.JComboBox<Integer> cboCheckInDay;
    private javax.swing.JComboBox<String> cboCheckInMonth;
    private javax.swing.JComboBox<Integer> cboCheckInYear;
    private javax.swing.JComboBox<Integer> cboCheckOutDay;
    private javax.swing.JComboBox<String> cboCheckOutMonth;
    private javax.swing.JComboBox<Integer> cboCheckOutYear;
    private javax.swing.JComboBox<String> cboRoomType;
    private java.awt.Checkbox checkbox1;
    private javax.swing.JMenuItem exitMenuItem;
    private javax.swing.JMenu fileMenu;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    public static javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JLayeredPane jLayeredPane1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanelAddRemoveGuest;
    private javax.swing.JPanel jPanelGuestDeadEnd;
    private javax.swing.JPanel jPanelGuestServices;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTable jTable1;
    public javax.swing.JTextArea jTextArea1;
    private javax.swing.JTree jTree1;
    private java.awt.Label label1;
    private java.awt.Label label2;
    private java.awt.Label label3;
    public javax.swing.JLabel lblStatus;
    private javax.swing.JMenuItem loadCSVMenuItem;
    private javax.swing.JMenuBar menuBar;
    private javax.swing.JMenuItem saveCSVMenuItem;
    private java.awt.TextField txtEmpName;
    private javax.swing.JTextField txtFullName;
    private javax.swing.JFormattedTextField txtID;
    private java.awt.TextField txtJobTitle;
    private javax.swing.JFormattedTextField txtSalary;
    // End of variables declaration//GEN-END:variables

}
