package team2hotel;

public class Option5 {
   

   //Output all previous guest stays
   public static void option5(Hotel hotel){
      System.out.println("All previous guest stays:");
      hotel.getGuestHistoricalInfo();
   }

}
