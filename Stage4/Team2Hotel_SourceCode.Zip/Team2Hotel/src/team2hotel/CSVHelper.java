package team2hotel;


import java.util.HashMap;
import java.io.*;
import javax.swing.JOptionPane;

public class CSVHelper {
    
    private HashMap<Integer, Guest> guests;
    private static final String filename = "guests.csv";
    private static final String delimiter = ",";
    
    public CSVHelper()
    {
        guests = new HashMap<>();
    }
    
    public void addGuest(Guest guest)
    {
        int id = guest.getuserID();
        guests.put(id, guest);
    }
    public Guest getGuest(int id)
    {
        return guests.get(id);
    }
    
    public void removeGuest(int id)
    {
        guests.remove(id);
    }
    
    
    public Guest getCustomer(int id)
    {
        return guests.get(id);
    }
    
    public HashMap<Integer, Guest> getGuests()
    {
        return guests;
    }
    
}
