package team2hotel;

public class Option6 {
   

   //Output all unclean rooms
   public static void option6(Hotel hotel){
      System.out.println("All room numbers to be cleaned:");
      hotel.getUncleanRooms();
   }

}
