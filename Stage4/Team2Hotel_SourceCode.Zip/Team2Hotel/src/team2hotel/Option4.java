package team2hotel;

public class Option4 {
   

   //Output all employees
   public static void option4(Hotel hotel){
      System.out.println("All employees:");
      hotel.getEmployeesInfo();
   }

}
